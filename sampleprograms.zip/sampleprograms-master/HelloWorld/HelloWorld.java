/**
 * To compile it from the Command Line:
 *     javac HelloWorld.java
 * To run it from the Command Line:
 *     java HelloWorld
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

package edu.cuny.brooklyn.cisc3120.AnimalGame;

public abstract class Feline extends Animal {
	public Feline(String name) {
		super(name);
	}
}

package edu.cuny.brooklyn.cisc3120.AnimalGameEnhanced;

public interface CatMotion extends FelineMotion {
	public void tap(Animal animal);
}

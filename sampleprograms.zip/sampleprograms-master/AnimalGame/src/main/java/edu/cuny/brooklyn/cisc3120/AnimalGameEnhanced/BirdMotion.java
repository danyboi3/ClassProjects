package edu.cuny.brooklyn.cisc3120.AnimalGameEnhanced;

public interface BirdMotion {
	public void fly(Direction direction, double speed, double distance);
}

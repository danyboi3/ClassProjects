package edu.cuny.brooklyn.cisc3120.AnimalGameEnhanced;

public interface WhaleMotion {
	public void swim(Direction direction, double speed, double distance);
}

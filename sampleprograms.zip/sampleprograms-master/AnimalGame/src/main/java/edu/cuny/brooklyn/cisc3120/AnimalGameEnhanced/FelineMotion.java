package edu.cuny.brooklyn.cisc3120.AnimalGameEnhanced;

public interface FelineMotion {
	public void walk(Direction direction, double speed, double distance);
	public void pounce(Animal prey);
}

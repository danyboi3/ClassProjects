package edu.cuny.brooklyn.cisc3120;

class Rowboat extends Boat {
    public void rowTheBoat() {
        System.out.print("Let's row ...");
    }
}


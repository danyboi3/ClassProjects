package edu.cuny.brooklyn.cisc3120;

class Sailboat extends Boat {
    public void move() {
        System.out.print("Let's sail ...");
    }
}
